# Introduction

This driver connects the SparkFun 9DoF Razor IMU M0 as an HMD with rotational tracking.
The SparkFun 9DoF Razor IMU M0 is an arduino compatible board. The needed Arduino sketch
for this driver can be found in the subdirectory "arduino\_gyro\_usb"
